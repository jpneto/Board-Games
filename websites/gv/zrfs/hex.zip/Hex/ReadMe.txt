Hex
---
Hex invented by both Piet Hein and John Nash, 
Implemented by Jeff Roy, July 2000.

Updated October 2000: fixed problems with Zillions 1.2.1;
improved computer play; updated graphics; 
added bonus game Snakes.


On both Hex and Snakes:
-----------------------
Object: Try to create a continuous chain of pieces linking 
your two sides of the board.

Note that the referee is not actually a player (he just checks 
to see whether someone has won), so don't try to play him.

Please report bugs to me at jroy2@slip.net.


In general, the best offense is a good defense.  Focus on 
preventing your opponent from forming an unbroken chain rather 
than on forming your own chain.

With perfect play, the first player can always force a win.  
A draw is impossible in this game.


On Hex:
-------
Hex is traditionally played on an 11x11 board.  This 
implementation uses smaller boards, and the first player is 
prohibited from playing his first piece onto the center.

Hex was discovered independently by Piet Hein and John Nash.


On Snakes:
----------
Take turns connecting your nodes with lines. 


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Hex.zrf" in the Open dialog and click "Open"

Hex.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

