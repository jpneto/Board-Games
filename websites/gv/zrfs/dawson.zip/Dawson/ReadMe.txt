Dawson's Chess 
Invented by T. R. Dawson
Rule file and graphics (c) 2002 W. D. Troyka
dtroyka@justice.com


Dawson's Chess is played on a chess board three units high by variable units in width (in this file, from 4 to 12 squares wide).  The row closest to each player is filled with Pawns belonging to that player.  The Pawns move like ordinary Chess Pawns except that capturing is compulsory.  Win by stalemating the opponent.

Each variant is a forced win in less than ten moves.  The winner depends on the board size, with Black winning on more board sizes than White.  Note that a Pawn can never make it across the board to the far rank, even though it is just two moves away.  It will always either be captured or blocked

Dawson's Chess was invented by Thomas Rayner Dawson, who is best known for his contributions to fairy chess.  He published five books on the subject between 1935 and 1947 and edited the Fairy Chess Review from 1930 until his death in 1951 in his native England.

Please send any comments or bug reports to dtroyka@justice.com.

----------------------------------------------------------------

To play:

Double click the Dawson game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Dawson.zrf" in the Open dialog and click "Open"

Dawson.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 


 