Gomullo
-------
Invented and implemented by Roland Johansson, 1999.

It's a cross between Gomoku and Othello: 
Two players alternate placing a disk on the board. The object is 
to get n in a row on a nxn-board. Example: 8 in a row on a 8x8 
board.
Moves are made just like regular Othello, with flipping in all 
legal directions.

The history on this game is as short as this sentence, 
being Roland Johansson's first succesful 'new' game for 
Zillions of Games.


This zip file can be extracted anywhere/anyway you like.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Gomullo.zrf" in the Open dialog and click "Open"

Gomullo.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

