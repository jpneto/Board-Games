Phutball
-------
Invented by John Conway
Implemented by Matthew Burke, 1999.

Philosopher's Football (aka Phutball) was invented by John Conway and
described in 'Winning Ways for Your Mathematical Plays' by E.R.Berlekamp, 
J.H.Conway and R.K.Guy (Academic Press Inc., ISBN: 0120911027).
 
The object of the game is to move the football to (or past) your goal 
line (the first player's goal is at the top) by jumping over lines of men.

On each turn you may either place a man or move the football.
The football jumps lines of adjacent men which are then removed from the 
board. If after jumping a line of men, the football lands next to another 
line of men, it may jump them as well, however this is not mandatory.

Phutball can be easily handicapped by adjusting the starting position of 
the football.


It's not recommended to play against the computer (unless you're easily 
amused), but Zillions does make it easy to play against another person
using Net-play.


You should have extracted this zip file preserving path names.

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Phutball.zrf" in the Open dialog and click "Open"

Phutball.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

