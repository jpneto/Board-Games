STOICAL GO
----------

Stoical Go was invented by Luis Bola�os Mures in September, 2012.

Zillions implementation by Luis Bola�os Mures.


PLAY

In this Go variant, standard ko rules don't apply. Instead, it's illegal 
to make a capture if your opponent made a capture on his previous move.

All other rules are the same as in Go. Suicide of one or more stones is 
not allowed, and area scoring is used.

NOTES

All known forced Go cycles (most of which are described at 
http://senseis.xmp.net/?Cycle) are impossible with this rule. 
The nature of the rule itself suggests that forced cycles are either 
impossible or astronomically rarer than they are in Go when the superko 
rule is not used.

This implementation uses stone scoring instead of area scoring for code 
simplicity and efficiency purposes. This means that the game will be won 
by the player who has more stones on the board at the end. However, you 
can make Zillions calculate the area score by filling territories manually 
at the end of the game with the board edit option.

You can place blocks the same way to change the size and shape of the board. 
As always, right clicking with C key down copies a piece, and right clicking 
with V key down pastes it. If you then drag the mouse, you can paste onto 
multiple positions.


--------------------------------------------------------
To play:

Double click the Stoical Go game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Stoical Go.zrf" in the Open dialog and click "Open"

Stoical Go.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com>