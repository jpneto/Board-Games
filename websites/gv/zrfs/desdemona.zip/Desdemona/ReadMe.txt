Desdemona
---------
Invented and implemented by Joao Pedro Neto, November 2000.


Desdemona is an Othello variant.

Othello rules: Black and White alternate putting disks on vacant 
squares from an initial opening position.  Each disk must be 
placed so that it sandwiches one or more enemy disks between 
itself and another friendly disk, with no empty squares intervening.  
The sandwiched enemy disks are flipped, changing color.

If one player can't move, he must pass his turn.  The game ends 
when neither side can move, usually when the whole board is filled.  
The winner is the player with the most pieces of his color.

Desdemona Rules: There is an extra stone, the grey one. When a 
player flips an enemy stone, it becomes grey. If a player flips 
a grey stone, it becomes one of his own stones.


----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Desdemona.zrf" in the Open dialog and click "Open"

Desdemona.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

