Gonnect

Game (c) 2000  Joao Pedro Neto
www.di.fc.ul.pt/~jpn/gv

Rules file and graphics (c) 2002  W. D. Troyka
dtroyka@justice.com


Gonnect is a popular connection game that incorporates the rules 
of Go.  It was invented by Joao Pedro Neto in 2000 and featured in 
an article in Issue 6 of Abstract Games Magazine.  The game is 
available for e-mail play at Richard's PBeM server at 
www.gamerz.net, and game strategy is discussed at Neto's World 
of Abstract Games site at www.di.fc.ul.pt/~jpn/gv.

The game is played on the points of a 13x13 square grid.  The 
players take turns placing stones on empty points on the board, 
with Black going first.  The object of the game is to form a 
chain of friendly stones connecting two opposite sides of the 
board.  A player can win by connecting the top edge to the 
bottom edge, or the left edge to the right edge.  The four corner 
points count in both left-right and top-bottom connections.  
Diagonally adjacent stones are not connected.

Gonnect incorporates the capture rules of Go.  If placing a stone 
results in the complete surrounding of an enemy group of stones, 
with no holes in that group, then the entire enemy group is 
captured and removed from the board.  Both friendly stones and 
the board edge are counted when determining whether an enemy 
group is surrounded.  The empty points adjacent to a group of 
connected friendly stones are called that group's `liberties.`  
Capturing occurs when the liberty of a group is reduced to zero.  
A single stone is considered a group of one.  Only orthogonal 
connnections are considered in determining captures and counting 
liberties.  A player cannot commit suicide by placing a stone 
into a group whose liberties are reduced to zero as a result of 
the move.  Capturing moves are always permitted and can never 
constitute a prohibited suicide.

Gonnect also uses the Go rule of "Ko," which is described in 
detail in the "Game Description" section under the Help menu.  
Unlike in Go, players cannot pass in Gonnect.  This means that 
the two-eyed groups considered uncapturable in Go can in fact 
be captured in Gonnect.  As the board fills up, a player may be 
forced to drop a stone into one of two eyes in a friendly group, 
thus permitting the opponent to play a stone in the remaining 
eye and capture the group.

Gonnect adopts the `pie` rule commonly used in Hex.  White has 
the option of changing places with Black on the first turn.  
This rule discourages Black from seeking a first-move advantage.

Please send any comments or bug reports to dtroyka@justice.com.


----------------------------------------------------------------

To play:

Double click the Gonnect game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Gonnect.zrf" in the Open dialog and click "Open"

Gonnect.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
