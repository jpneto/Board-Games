
Atoms (ver. 1.2)
-------------------------------------------------------------------
***** Requires Zillions version 1.2 or higher to play. *****
-------------------------------------------------------------------
Invented by Robert A. Kraus in 1981 and 2000
Implemented by Robert A. Kraus for Zillions of Games 
-------------------------------------------------------------------
You should have extracted this zip file preserving path names,
(Check "Use Folder Names" box in Win-Zip Extract Files Dialog Box);
and you should extract to your Zillions Rules folder.This will
create an Atoms folder within the Rules folder.
-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Atoms" folder in the Open dialog and click "Open"
4. Select "Atoms.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
Atoms.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
