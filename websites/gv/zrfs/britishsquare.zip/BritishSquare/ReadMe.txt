British Square
(c) 1978  Gabriel Publishing
Rules file and graphics (c) 2002 W. D. Troyka
dtroyka@justice.com


The players take turns placing pieces on empty squares.  
A piece cannot be placed in a square that is orthogonally 
adjacent to an enemy piece.  The first piece cannot be 
dropped in the center square.  A player who has no move 
must pass.  The other player can continue placing pieces 
as long as possible.  

The player with the most pieces on the board at the end 
of a game wins that game.  That player scores a number of 
points equal to the number of pieces he has in excess of 
the opponent.  The players then continue playing games, 
alternating who goes first, until one player accumulates 
seven points.  That player is the overall winner.


----------------------------------------------------------------

To play:

Double click the BritishSquare game icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "BritishSquare.zrf" in the Open dialog and click "Open"

BritishSquare.zrf is a rules file used by the Windows program 
"Zillions of Games".  Zillions of Games allows you to play 
any number of games against the computer or over the Internet. 
Zillions of Games can be purchased online.  For more information,
please visit the Zillions of Games website:

              <http://www.zillions-of-games.com> 
