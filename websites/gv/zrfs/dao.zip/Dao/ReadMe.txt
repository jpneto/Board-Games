Dao
---
Designed by Jeff Pickering and Ben van Buskirk, copyright 2001 PlayDAO.com
Implemented by L. Lynn Smith, July 2001.


A seemingly simple alignment game designed by Jeff Pickering and 
Ben van Buskirk.

Two players begin with their pieces arranged in two seperate diagonals 
upon a 4x4 field.

The object of the game is to move your pieces into a orthogonal alignment 
or to occupy the four corners or into a 2x2 square.

Cornering an opponent's piece, blocking it in one of the four corners with 
three of your pieces, will lose you the game.

The pieces move by sliding, diagonal or orthogonal, until they either reach
the edge of the board or another piece blocks their travel.
They cannot jump.
They cannot capture.
They only slide.

Sound easy? Go ahead and give this game a go. 


Dao is the Way.

----------------------------------------------------------------
To play:

Double click the Dao icon, or

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Dao.zrf" in the Open dialog and click "Open"

Dao.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

 
