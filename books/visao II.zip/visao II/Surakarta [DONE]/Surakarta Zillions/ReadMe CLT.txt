Surakarta
---------
Originally implemented by Steve Evans, 1998.

Surakarta CLT: modified by Chris Lusby Taylor, 2000.


Surakarta is an Indonesian, two-player, abstract board game. 

Surakarta_CLT.zrf plays the same game as the original, but 
its code is shorter, clearer and faster than the original.


To learn how to play, choose "Game Description" from the Help menu. 

----------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Surakarta.zrf" or "Surakarta_CLT.zrf" in the Open dialog and click "Open"

Surakarta.zrf and Surakarta_CLT.zrf are rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 

